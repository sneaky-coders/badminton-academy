// db.js
const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: '162.214.80.88',
  user: 'idzzdcmy_badminton',
  password: 'Zaahid97!',
  database: 'idzzdcmy_badminton',
});

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
  } else {
    console.log('Connected to MySQL database');
  }
});

module.exports = connection;
